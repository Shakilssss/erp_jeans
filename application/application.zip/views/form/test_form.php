<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">
<html xmlns="http://www.w3.org/1999/xhtml">
<head>
<meta http-equiv="Content-Type" content="text/html; charset=iso-8859-1" />
<title>Test Document</title>
</head>

<body>
<form action="<?php echo base_url();?>index.php/payroll_con/company_info_view" method="post" >
<input type="text" name="name"  value="" />
<input type="submit" name="submit" value="Submit" />
</form>

</body>
</html>
