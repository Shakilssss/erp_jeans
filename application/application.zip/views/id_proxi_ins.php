<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">
<html xmlns="http://www.w3.org/1999/xhtml">
<head>
<meta http-equiv="Content-Type" content="text/html; charset=iso-8859-1" />
<title>MSL Payroll</title>
</head>

<body bgcolor="#ECE9D8">
<div style="margin:0 auto; width:100%; height:auto; overflow:hidden; text-align:center;">
<h3 style="text-align:center;"> MSH ERP SYSTEMS </h3>
<h4 style="text-align:center;"> Developed by Mysoftheaven (BD) Ltd. </h4>
<h3 class="style1" style="font-size:13px; font-weight:bold;">Head Office : 19-B/2-C, Block#F, 5th Floor, Ring Road, Shyamoli, Dhaka-1207, Bangladesh. </h3>
<h3 class="style1" style="font-size:13px; font-weight:bold;">Corporate Office : 8813 NW 23 Street, Miami, FL 33172, USA. </h3>
<h3 class="style1" style="font-size:13px; font-weight:bold;">Phone : 88-02-55020230 | Cell : 88-01970776609</h3>
<h3 class="style1" style="font-size:13px; font-weight:bold;">
Website : <a style="text-decoration:none; color:#0066FF;" href="http://www.mysoftheaven.com"  target="_blank">www.mysoftheaven.com</a></h3>
<div style="text-align:center;"> <img width="120" src="<?php echo base_url(); ?>uploads/company_photo/logo.gif" /> </div>

</div>
</body>
</html>