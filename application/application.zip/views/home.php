<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">
<html xmlns="http://www.w3.org/1999/xhtml"><head id="Head1"><title>
	JMCL Payroll System
</title><meta http-equiv="content-type" content="text/html; charset=UTF-8" charset="windows-1252">

	
	<style>
	BODY { SCROLLBAR-FACE-COLOR: #7e9ac2; SCROLLBAR-ARROW-COLOR: black  }</style>

	</head>
    <frameset rows="50,*,20">
    	   		<frame src="<?php echo base_url();?>index.php/payroll_con/main_header" name="bottomFrame" noresize="noresize" framespacing="0" frameborder="NO" border="0" scrolling="NO" >

    	<frameset id="inner" cols="269,80%">
    	    <frame name="left" src="<?php echo base_url();?>index.php/payroll_con/utree" scrolling="YES">
    		<frame name="right" src="<?php echo base_url();?>index.php/payroll_con/first_body" framespacing="0" frameborder="NO" border="0">
        </frameset>
        <frame src="<?php echo base_url();?>index.php/payroll_con/footer" name="bottomFrame" noresize="noresize" framespacing="0" frameborder="NO" border="0" scrolling="NO">

    </frameset><noframes></noframes>	
  	

</html>